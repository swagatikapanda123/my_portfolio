<!DOCTYPE html>
<html>
<head>
	<title>Swagatika's Space</title>
	<script type="text/javascript" src="jquery/JQuery.js"></script>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="Bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <style>
    .image {
    height: 200px;
    width: 175px;
    }
    #f{
      margin-left: 350px;
    }
    
    .nav-item:hover{
      border-bottom: 2px solid blue;
    }
    #sub{
      border-radius: 5px;
      width: 100px;
      background-image: linear-gradient(#338FB5,#3BA5D0,#45C0F1,#76D3F9);
    }
    #frm{
      background-image: linear-gradient(#338FB5,#3BA5D0,#45C0F1,#76D3F9);
      height: 250px;
    }
    </style>
</head>
<body>
  <div class="text-center" style="margin-bottom:0;background-image: linear-gradient(#3BA5D0,#45C0F1,#76D3F9);">
    <img src="cat.jpg" style="border-radius: 50%; margin-left: 0">
    <h1>Welcome To My Page</h1><hr>
    <center><h5>Cats | Music | Books | Taylor Swift</h5></center>
</div>
   <nav class="navbar navbar-expand-sm bg-light navbar-light sticky-top">
      <a class="nav-link" href="#">Home</a>
      <button class="navbar-toggler" data-toggle="collapse" data-target="#collapsibleNavbar">
      <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="collapsibleNavbar">
         <ul class="navbar-nav">
              <li class="nav-item">
                 <a class="nav-link" href="#about"></span>About</a>
              </li>
              <li class="nav-item">
                 <a class="nav-link" href="#projects">Projects</a>
              </li>
              <li class="nav-item">
        		 <a class="nav-link" href="#contact">Contact</a>
               </li>    
        </ul>
            
      </div> 
     
 </nav>
<div class="container" style="margin-top:30px">
  <div class="row">
    <div class="col-sm-4">
      <h2>Me</h2>
      <div class="container">
      <img src="swag12.jpg" class="image">
      <p style="font-style: italic;">I'm The Only One Of ME!</p>
      <hr>
    </div>
    <div>
    	<p><i class="fa fa-home"></i> Bhubaneswar, Odisha</p>
          <p><i class="fa fa-envelope"></i> swagatikapanda164@gmail.com</p>
          <p><i class="fa fa-phone"></i> 8658300375</p>
    </div>
      <h3>Find me on Social Media</h3><hr>
      <ul class="nav nav-pills flex-column">
        <li class="nav-item"><a class="nav-link" href="https://twitter.com/swagati89888210" target="_blank"><span><i class="fa fa-twitter">Twitter</i></span></a></li>
          
          <li class="nav-item">
          <a class="nav-link" href="https://www.instagram.com/_swagatika__/" target="_blank"><span><i class="fa fa-instagram">       Instagram</i></span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="https://www.linkedin.com/in/swagatika-panda-7b0414181/" target="_blank"><span><i class="fa fa-linkedin">        LinkedIn</i></span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="https://github.com/swagatikapanda123" target="_blank"><span><i class="fa fa-github">        GitHub</i></span></a>
        </li>
      </ul>
      <hr class="d-sm-none">
    </div>
    <div class="col-sm-8">
      <div id="about"><h2>ABOUT</h2><hr>
<p>Hello friends! Let’s start wih the introductions. On formal documents, papers, certificates, etc. I’m known as Swagatika Panda. On most social platforms I go by the name Swagatika. Otherwise, don’t bother much. Call me Swag.</p> <h2>Philosophies, any?</h2> <p>The one quote that has really stuck with me through all these years is</p> <blockquote> <p>Its always the journey that matters, not the destination.</p> </blockquote> <p>And I like to have faith in equality.</p> <h2 >Who am I right now?</h2> <p>I’m a developer in making, greatly enthused by python, C++, and javascript. I am pursuing Bachelors in Information Technology from BJB Autonomous College, Bhubaneswar. Throw in some musical notes and sick beats and we could be having fun hacking together! :) Oh also, I’m hilarious. I promise.</p> <p>Any messages or tweets coming my way are more than welcome.</p>
<h5 style="font-family: Times New Roman; color:black; text-align:center; border-radius: 5px;background-image: linear-gradient(#338FB5,#3BA5D0,#45C0F1,#76D3F9);width: 100px;margin-left: 300px">
<a style="text-decoration: none" href="https://drive.google.com/file/d/10Tu1jSeMbHzFXoSh0mvbRcJByEDSV744/view"><strong>RESUME</strong></a></h5>
<hr>
</div>
<div id="contact">
  <h2 class="text-center">Drop A Message!!</h2>
  <form>
    <div class="form-group">
      <label class="control_label">Name:</label><input type="text" class="form-control" placeholder="Name..">
      <label class="control_label">E-mail:</label><input type="text" class="form-control" placeholder="Email..">
      <label class="control_label">Message:</label><input type="text" class="form-control" placeholder="Message.">
      <br><br>
     <button type="submit" class="btn btn-primary">Send</button>

    </div>
</form>
</div>
 </div>


</div>
<footer class="footer">footer elements
  
</footer>
</body>
</html>